/**
 * Excerpted from the book, "Pragmatic Unit Testing in Java with JUnit"
 * ISBN 0-9745140-1-2
 * Copyright 2003 The Pragmatic Programmers, LLC.  All Rights Reserved.
 * Visit www.PragmaticProgrammer.com
 */


import java.util.ArrayList;

class Main {


public void addit(Object anObject){
  ArrayList myList = new ArrayList();
  myList.add(anObject);
  myList.add(anObject);
  // more code...
}



public static void Main() {

}

}
