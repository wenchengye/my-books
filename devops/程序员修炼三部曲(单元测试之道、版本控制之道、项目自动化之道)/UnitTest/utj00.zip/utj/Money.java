/**
 * Excerpted from the book, "Pragmatic Unit Testing in Java with JUnit"
 * ISBN 0-9745140-1-2
 * Copyright 2003 The Pragmatic Programmers, LLC.  All Rights Reserved.
 * Visit www.PragmaticProgrammer.com
 */

public class Money {

  public int compare (Money other) {
    return -1;
  }

  public double asDouble() {
    return 0.0d;
  }
}
