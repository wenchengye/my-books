#!/bin/sh
#
# Excerpted from the book, "Pragmatic Project Automation"
# ISBN 0-9745140-3-9
# Copyright 2004 The Pragmatic Programmers, LLC.  All Rights Reserved.
# Visit www.PragmaticProgrammer.com
#


#$CC_HOME/main/bin/cruisecontrol.sh -projectname dms -lastbuild 20040312142200 -configfile config.xml -port 7070

$CC_HOME/main/bin/cruisecontrol.sh
